// /js/core/emergencyAdmin.js
// Creates an emergency admin user WITHOUT affecting the current (primary) session.
// ⚠️ CAMBIAR admin2025 en producción.
//
// Defensive behavior:
// - No early return based on Firestore: a directory doc does NOT guarantee the Auth user exists.
// - Always ensure Auth first (sign-in or create), then ensure Firestore profile + users_directory.

import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword
} from "https://www.gstatic.com/firebasejs/11.6.1/firebase-auth.js";

import {
  doc,
  setDoc,
  collection
} from "https://www.gstatic.com/firebasejs/11.6.1/firebase-firestore.js";

import { APP_ID, DOMAIN_SUFFIX } from "./firebase.js";
import { getSecondary } from "./secondary.js";

function profileDoc(db, uid) {
  return doc(db, "artifacts", APP_ID, "users", uid, "profile", "data");
}

function usersDirectoryCollection(db) {
  return collection(db, "artifacts", APP_ID, "public", "data", "users_directory");
}

function friendlyAuthError(e) {
  const code = e?.code || "";
  if (code === "auth/operation-not-allowed") {
    return "En Firebase Auth debes habilitar Email/Password (Authentication → Sign-in method).";
  }
  if (code === "auth/network-request-failed") {
    return "Fallo de red al conectar con Firebase Auth. Revisa internet y dominios autorizados.";
  }
  if (code === "auth/invalid-email") {
    return "Email inválido para el admin de emergencia.";
  }
  if (code === "auth/too-many-requests") {
    return "Demasiados intentos. Espera un momento y recarga.";
  }
  return "No se pudo asegurar el admin de emergencia.";
}

/**
 * Ensures emergency admin exists.
 * Returns: { email, createdAuth, uid }
 */
export async function ensureEmergencyAdmin() {
  const { secondaryAuth, secondaryDb } = await getSecondary();

  const email = `admin${DOMAIN_SUFFIX || "@mediflow.sys"}`;
  const password = "admin2025";

  let createdAuth = false;
  let cred;

  // 1) Ensure Auth user
  try {
    cred = await signInWithEmailAndPassword(secondaryAuth, email, password);
  } catch (e) {
    const code = e?.code || "";
    if (code === "auth/user-not-found") {
      cred = await createUserWithEmailAndPassword(secondaryAuth, email, password);
      createdAuth = true;
    } else if (code === "auth/wrong-password" || code === "auth/invalid-credential") {
      // The account exists, but password differs.
      // The safest recovery is to delete that Auth user from Firebase Console and reload the app.
      const err = new Error(
        "El usuario admin ya existe en Firebase Auth, pero la contraseña NO coincide con 'admin2025'. " +
        "Solución rápida: Firebase Console → Authentication → Users → elimina '" + email + "' y recarga la app para recrearlo."
      );
      err.cause = e;
      throw err;
    } else {
      const err = new Error(friendlyAuthError(e));
      err.cause = e;
      throw err;
    }
  }

  const uid = cred.user.uid;

  // 2) Ensure Firestore profile
  await setDoc(
    profileDoc(secondaryDb, uid),
    {
      dni: "",
      name: "Super Admin",
      username: "admin",
      role: "admin",
      jobTitle: ["Super Admin"],
      requireIpApproval: false,
      ipUnlockKey: "",
      authorizedDevices: [],
      activeSessionId: "",
      status: "active",
      lastLogin: ""
    },
    { merge: true }
  );

  // 3) Ensure directory doc (use uid as docId)
  await setDoc(
    doc(usersDirectoryCollection(secondaryDb), uid),
    {
      uid,
      dni: "",
      name: "Super Admin",
      username: "admin",
      role: "admin",
      jobTitle: ["Super Admin"],
      createdAt: new Date().toISOString()
    },
    { merge: true }
  );

  return { email, createdAuth, uid };
}
